package com.example.transferablefool;

public class Main {
    public static void main(final String[] args) {
        GameApplication.main(args);
    }
}